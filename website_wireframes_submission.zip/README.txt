Website Wireframes – Portfolio Website

This submission includes grayscale wireframe sketches for a responsive portfolio website.

Included views:
- Home / Landing Page: mobile and desktop
- About Page: mobile and desktop
- Projects Page: mobile and desktop
- Contact Page: mobile and desktop

Design note:
I planned the mobile layouts first and then adapted them for larger screens. The wireframes focus on clear navigation, readable content, project cards, and a simple contact form. During implementation, I will check that the layout works at different screen sizes, that images have alt text, and that navigation and forms remain accessible.

The image is a wireframe sketch board, not screenshots of completed web pages.
